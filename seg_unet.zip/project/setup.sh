#!/bin/bash

# Libraries
pip install keras-unet
pip install optuna
pip install tensorboard

pip install rasterio
pip install matplotlib

# To use CPU
pip install tensorflow
# To use GPU
pip install tensorflow-gpu

# Directories
mkdir content
cd content
mkdir images train train_seg test test_seg val val_seg
