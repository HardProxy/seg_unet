# -*- coding: utf-8 -*-
# General Purpose libraries
import pandas as pd
import numpy as np

# Image visualization
import matplotlib.pyplot as plt
import matplotlib

# Machine Learning
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras import layers
from keras_unet.models import custom_unet
from keras_unet.models import vanilla_unet

#Build-in utilities functions
import os, sys, shutil, glob

import rasterio as rio

# Path to images .tif

img_2_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/CSKS3_20180605_deGrandi.tif'
img_1_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/CSKS3_20181008_deGrandi.tif'
output_img_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/binaria_jun_out_treinamento.tiff'

# Reading the first input image
with rio.open(img_1_path) as rio_raster:
  img_1 = rio_raster.read(1) # Lendo apenas a primeira banda

# Reading the second input image
with rio.open(img_2_path) as rio_raster:
  img_2 = rio_raster.read(1) # Lendo apenas a primeira banda

# Reading the output image
with rio.open(output_img_path) as rio_raster:
  output_img = rio_raster.read(1) # Lendo apenas a primeira banda

# Tamanho da imagem cortada
cut_size = 64
half_cut = int(cut_size/2)
# Varrendo imagem original e recortando subconjuntos para as 3 imgens
for i in range(half_cut, img_1.shape[0]-half_cut, cut_size):
  for j in range(half_cut, img_1.shape[1]-half_cut, cut_size):

    cuted_img_1 = img_1[i - half_cut: i + half_cut,
                        j - half_cut: j + half_cut].copy() # recorte
    matplotlib.image.imsave('/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/in_1_'+str(i)+'_'+str(j)+'.jpeg',cuted_img_1) # salvando as imagens

    cuted_img_2 = img_2[i - half_cut: i + half_cut,
                        j - half_cut: j + half_cut].copy() # recorte
    matplotlib.image.imsave('/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/in_2_'+str(i)+'_'+str(j)+'.jpeg',cuted_img_2) # salvando as imagens

    cuted_output_img = output_img[i - half_cut: i + half_cut,
                                  j - half_cut: j + half_cut].copy() # recorte
    matplotlib.image.imsave('/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/out_'+str(i)+'_'+str(j)+'.jpeg',cuted_output_img) # salvando as imagens

test_split = .2 # 20% de todos os dados para testes
val_split = .15 # 15% dos dados de treino para validação
train_split = 1 - test_split

"""##Train, Validation and Test data"""

# Caminhos para as pastas
train_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/train/'
train_seg_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/train_seg/'
test_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/test/'
test_seg_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/test_seg/'
val_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/val/'
val_seg_path = '/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/val_seg/'

"""### Directories"""

#Separação entre treino, teste e validação
#Movendo imagens para seus respectivos diretórios
for i in range(half_cut, img_1.shape[0]-half_cut, cut_size):
  for j in range(half_cut, img_1.shape[1]-half_cut, cut_size):
    file_in1 = 'in_1_'+str(i)+'_'+str(j)+'.jpeg'
    file_in2 = 'in_2_'+str(i)+'_'+str(j)+'.jpeg'
    out_file = 'out_'+str(i)+'_'+str(j)+'.jpeg'
    if np.random.rand() > test_split:
      if np.random.rand() > val_split :# treinamento
        #mover imagem para pasta de treinamento
        shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+file_in1,train_path+file_in1)
        shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+file_in2,train_path+file_in2)
        shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+out_file,train_seg_path+out_file)
      else : #validation      
        #mover imagem para pasta de validação
        shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+file_in1,val_path+file_in1)
        shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+file_in2,val_path+file_in2)
        shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+out_file,val_seg_path+out_file)
    else: #teste
      #mover imagem para pasta de teste
      shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+file_in1,test_path+file_in1)
      shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+file_in2,test_path+file_in2)
      shutil.move("/home/dirac/Documents/INPE/3_periodo/DSGeo/project/content/images/"+out_file,test_seg_path+out_file)

"""### Variable's datasets

#### X_train - y_train
"""

#Criando variável para conter o conjunto de treinamento
count = 0
os.chdir(train_path)
for file in glob.glob("*.jpeg"):
  splited_file_name = file.split('_')
  i = int(splited_file_name[2])
  j = int(splited_file_name[3][:-5])
  if splited_file_name[1] == '1':
    file_in1 = 'in_1_'+str(i)+'_'+str(j)+'.jpeg'
    file_in2 = 'in_2_'+str(i)+'_'+str(j)+'.jpeg'
    
    im1 = rio.open(train_path + file_in1).read(1)
    img1 = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(im1),axis=0)/255 #(64,64,1) -> (1,64,64,1)

    im2 = rio.open(train_path + file_in2).read(1)
    img2 = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(im2),axis=0)/255 #(64,64,1) -> (1,64,64,1)

    if count == 0:
       X_train = tf.concat([img1,img2], axis=3) # (1,64,64,2)
    else:
      X_train = tf.concat([X_train,tf.concat([img1,img2], axis=3)],axis=0) # (n_train,64,64,2)
      
    file_out = 'out_'+str(i)+'_'+str(j)+'.jpeg'
    mask = rio.open(train_seg_path+file_out).read(1)
    mask_tf = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(mask),axis=0)/255
    if count == 0:
      y_train = mask_tf
    else:
      y_train = tf.concat([y_train, mask_tf], axis=0)
    
    count+=1

"""#### X_test - y_test"""

#Criando variável para conter o conjunto de treinamento
count = 0
os.chdir(test_path)
for file in glob.glob("*.jpeg"):
  splited_file_name = file.split('_')
  i = int(splited_file_name[2])
  j = int(splited_file_name[3][:-5])
  if splited_file_name[1] == '1':
    file_in1 = 'in_1_'+str(i)+'_'+str(j)+'.jpeg'
    file_in2 = 'in_2_'+str(i)+'_'+str(j)+'.jpeg'
    
    im1 = rio.open(test_path + file_in1).read(1)
    img1 = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(im1),axis=0)/255 #(64,64,1) -> (1,64,64,1)

    im2 = rio.open(test_path + file_in2).read(1)
    img2 = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(im2),axis=0)/255 #(64,64,1) -> (1,64,64,1)

    if count == 0:
       X_test = tf.concat([img1,img2], axis=3) # (1,64,64,2)
    else:
      X_test = tf.concat([X_test,tf.concat([img1,img2], axis=3)],axis=0) # (n_train,64,64,2)

    file_out = 'out_'+str(i)+'_'+str(j)+'.jpeg'
    mask = rio.open(test_seg_path+file_out).read(1)
    mask_tf = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(mask),axis=0)/255
    if count == 0:
      y_test = mask_tf
    else:
      y_test = tf.concat([y_test, mask_tf], axis=0)

    count+=1

"""#### X_val - y_val"""

#Criando variável para conter o conjunto de treinamento
count = 0
os.chdir(val_path)
for file in glob.glob("*.jpeg"):
  splited_file_name = file.split('_')
  i = int(splited_file_name[2])
  j = int(splited_file_name[3][:-5])
  if splited_file_name[1] == '1':
    file_in1 = 'in_1_'+str(i)+'_'+str(j)+'.jpeg'
    file_in2 = 'in_2_'+str(i)+'_'+str(j)+'.jpeg'
    
    im1 = rio.open(val_path + file_in1).read(1)
    img1 = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(im1),axis=0)/255 #(64,64,1) -> (1,64,64,1)

    im2 = rio.open(val_path + file_in2).read(1)
    img2 = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(im2),axis=0)/255 #(64,64,1) -> (1,64,64,1)

    if count == 0:
       X_val = tf.concat([img1,img2], axis=3) # (1,64,64,2)
    else:
      X_val = tf.concat([X_val,tf.concat([img1,img2], axis=3)],axis=0) # (n_train,64,64,2)

    file_out = 'out_'+str(i)+'_'+str(j)+'.jpeg'
    
    mask = rio.open(val_seg_path+file_out).read(1)
    mask_tf = tf.expand_dims(tf.keras.preprocessing.image.img_to_array(mask),axis=0)/255
    if count == 0:
      y_val = mask_tf
    else:
      y_val = tf.concat([y_val, mask_tf], axis=0)
      
    count+=1

print(X_train.shape, y_train.shape)

# Transformando em tensores
X_train = tf.convert_to_tensor(X_train)
y_train = tf.convert_to_tensor(y_train)
X_test = tf.convert_to_tensor(X_test)
y_test = tf.convert_to_tensor(y_test)

"""## U-Net"""

tf.keras.backend.clear_session()
print(tf.config.list_physical_devices('GPU'))
tf.debugging.set_log_device_placement(True)

# Definindo o modelo #(N-train, 64, 64, 2)
model = custom_unet(
    input_shape=(cut_size, cut_size, 2), 
    use_batch_norm=True,
    num_classes=1,
    filters=64,
    dropout=0.25,
    output_activation='sigmoid')

model.summary()

model.compile(optimizer='adam', 
              loss='mse', 
              metrics=[tf.keras.metrics.MeanSquaredError()])

# Treinamento 
history = model.fit(X_train, y_train, epochs=700, validation_split=.3 )

loss = history.history['loss']
val_loss = history.history['val_loss']
epochsL=range(len(loss))

plt.plot(epochsL,loss,label='Training_loss',color='blue')
plt.plot(epochsL,val_loss,label='Validation_loss',color='red')
plt.legend()
plt.title("Unet - Training and Validation loss")

"""# Teste"""

predicted_mask = model.predict(X_test)

model.evaluate(X_test,y_test)

idx_img = 22
plt.figure(figsize=(10,5))

plt.subplot(141)
plt.title('Input 1 ')
plt.imshow(X_test[idx_img,:,:,0])
plt.subplot(142)
plt.title('Input 2')
plt.imshow(X_test[idx_img,:,:,1])
plt.subplot(143)
plt.title('Output Desejado')
plt.imshow(y_test[idx_img,:,:,0])
plt.subplot(144)
plt.title('Output Previsto')
plt.imshow(predicted_mask[idx_img,:,:,0])

for idx_img in range(X_test.shape[0]):

  plt.figure(figsize=(10,5))

  plt.subplot(141)
  plt.title('Input 1 '+str(idx_img))
  plt.imshow(X_test[idx_img,:,:,0])
  plt.subplot(142)
  plt.title('Input 2')
  plt.imshow(X_test[idx_img,:,:,1])
  plt.subplot(143)
  plt.title('Output Desejado')
  plt.imshow(y_test[idx_img,:,:,0])
  plt.subplot(144)
  plt.title('Output Previsto')
  plt.imshow(predicted_mask[idx_img,:,:,0])